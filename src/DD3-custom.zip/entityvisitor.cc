#include "entityvisitor.h"

EntityVisitor::~EntityVisitor() {}
